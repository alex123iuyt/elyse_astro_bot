export function getRole(): 'admin' | 'user' {
  // This function is used in client components, so we only check localStorage
  if (typeof window === 'undefined') {
    return 'user'; // Default fallback for SSR
  }
  
  const role = localStorage.getItem('elyse.role');
  return role === 'admin' ? 'admin' : 'user';
}

export function setRole(role: 'admin' | 'user'): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem('elyse.role', role);
}



