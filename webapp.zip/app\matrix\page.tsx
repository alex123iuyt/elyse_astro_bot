export default function MatrixPage() {
  return (
    <div className="min-h-screen bg-black text-white p-6 space-y-4">
      <h1 className="text-xl font-semibold">Матрица судьбы</h1>
      <div className="card">Здесь будет матрица судьбы. Заглушка.</div>
    </div>
  )
}

















