import Groq from 'groq-sdk';

// Инициализируем клиент Groq
const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY || 'your-groq-api-key',
});

export interface AIGenerationOptions {
  model?: string;
  temperature?: number;
  maxTokens?: number;
  systemPrompt?: string;
}

export class GroqAIClient {
  private defaultModel = 'llama3-8b-8192'; // Быстрая модель
  
  async generateText(
    prompt: string, 
    options: AIGenerationOptions = {}
  ): Promise<string> {
    try {
      const completion = await groq.chat.completions.create({
        messages: [
          ...(options.systemPrompt ? [{
            role: 'system' as const,
            content: options.systemPrompt
          }] : []),
          {
            role: 'user' as const,
            content: prompt,
          },
        ],
        model: options.model || this.defaultModel,
        temperature: options.temperature || 0.7,
        max_tokens: options.maxTokens || 1024,
        stream: false,
      });

      return completion.choices[0]?.message?.content || '';
    } catch (error) {
      console.error('Groq AI generation error:', error);
      throw new Error('Failed to generate content with Groq');
    }
  }

  async generateBatch(
    prompts: Array<{
      prompt: string;
      options?: AIGenerationOptions;
    }>
  ): Promise<string[]> {
    const results = await Promise.allSettled(
      prompts.map(({ prompt, options }) => 
        this.generateText(prompt, options)
      )
    );

    return results.map(result => 
      result.status === 'fulfilled' ? result.value : ''
    );
  }

  // Специализированные методы для астрологического контента
  async generateDailyTip(theme: string): Promise<string> {
    const systemPrompt = `Ты - мудрый астролог и духовный наставник. 
    Создавай короткие, вдохновляющие советы дня на русском языке.
    Стиль: мудрый, позитивный, практичный.
    Длина: 1-2 предложения, максимум 150 символов.`;

    const prompt = `Создай совет дня на тему: ${theme}`;
    
    return this.generateText(prompt, {
      systemPrompt,
      temperature: 0.8,
      maxTokens: 100
    });
  }

  async generateHoroscope(zodiacSign: string, date: string): Promise<{
    general: string;
    love: string;
    career: string;
    health: string;
  }> {
    const systemPrompt = `Ты - профессиональный астролог. 
    Создавай точные, персональные гороскопы на русском языке.
    Стиль: профессиональный, конкретный, полезный.
    Избегай общих фраз, давай конкретные советы.`;

    const prompts = [
      {
        prompt: `Создай общий гороскоп для знака ${zodiacSign} на ${date}. 2-3 предложения.`,
        options: { systemPrompt, maxTokens: 150 }
      },
      {
        prompt: `Создай прогноз в любви для знака ${zodiacSign} на ${date}. 1-2 предложения.`,
        options: { systemPrompt, maxTokens: 100 }
      },
      {
        prompt: `Создай прогноз в карьере для знака ${zodiacSign} на ${date}. 1-2 предложения.`,
        options: { systemPrompt, maxTokens: 100 }
      },
      {
        prompt: `Создай прогноз здоровья для знака ${zodiacSign} на ${date}. 1-2 предложения.`,
        options: { systemPrompt, maxTokens: 100 }
      }
    ];

    const results = await this.generateBatch(prompts);
    
    return {
      general: results[0] || '',
      love: results[1] || '',
      career: results[2] || '',
      health: results[3] || ''
    };
  }

  async generateLunarAdvice(phase: string, sign: string): Promise<string> {
    const systemPrompt = `Ты - эксперт по лунной астрологии.
    Создавай практические советы на основе лунных фаз и знаков.
    Стиль: мистический, но практичный.
    Длина: 2-3 предложения.`;

    const prompt = `Дай совет для лунной фазы "${phase}" в знаке ${sign}`;
    
    return this.generateText(prompt, {
      systemPrompt,
      temperature: 0.7,
      maxTokens: 200
    });
  }
}

// Экспортируем singleton
export const groqAI = new GroqAIClient();

