// Инициализация демо-данных для админки
export const initializeDemoData = () => {
  if (typeof window === 'undefined') return;

  // Инициализируем пользователей
  if (!localStorage.getItem('elyse.users')) {
    const demoUsers = [
      {
        id: '1',
        name: 'Анна Петрова',
        email: 'anna@example.com',
        role: 'user',
        status: 'active',
        createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        lastActivity: new Date().toISOString(),
        messageCount: 15,
        isPremium: true,
        subscription: { type: 'monthly', price: 999 }
      },
      {
        id: '2',
        name: 'Михаил Сидоров',
        email: 'mikhail@example.com',
        role: 'user',
        status: 'active',
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        lastActivity: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        messageCount: 8,
        isPremium: false
      },
      {
        id: '3',
        name: 'Елена Козлова',
        email: 'elena@example.com',
        role: 'user',
        status: 'active',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        lastActivity: new Date().toISOString(),
        messageCount: 3,
        isPremium: false
      }
    ];
    localStorage.setItem('elyse.users', JSON.stringify(demoUsers));
  }

  // Инициализируем чаты
  if (!localStorage.getItem('elyse.chats')) {
    const demoChats = [
      {
        id: '1',
        userId: '1',
        status: 'active',
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        lastActivity: new Date().toISOString()
      },
      {
        id: '2',
        userId: '2',
        status: 'resolved',
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        lastActivity: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '3',
        userId: '3',
        status: 'active',
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        lastActivity: new Date().toISOString()
      }
    ];
    localStorage.setItem('elyse.chats', JSON.stringify(demoChats));
  }

  // Инициализируем сообщения
  if (!localStorage.getItem('elyse.messages')) {
    const demoMessages = [
      {
        id: '1',
        chatId: '1',
        content: 'Здравствуйте! У меня вопрос о совместимости со Стрельцом',
        is_from_user: true,
        is_read: true,
        created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '2',
        chatId: '1',
        content: 'Здравствуйте, Анна! Конечно, я помогу вам разобраться с совместимостью. Стрелец - огненный знак, очень энергичный и оптимистичный.',
        is_from_user: false,
        is_read: false,
        created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '3',
        chatId: '2',
        content: 'Какие планы на неделю?',
        is_from_user: true,
        is_read: true,
        created_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '4',
        chatId: '2',
        content: 'На этой неделе у вас благоприятное время для планирования и начала новых проектов. Особенно удачными будут вторник и четверг.',
        is_from_user: false,
        is_read: true,
        created_at: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: '5',
        chatId: '3',
        content: 'Привет! Как дела?',
        is_from_user: true,
        is_read: true,
        created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
      }
    ];
    localStorage.setItem('elyse.messages', JSON.stringify(demoMessages));
  }

  // Инициализируем премиум пользователей
  if (!localStorage.getItem('elyse.premiumUsers')) {
    const demoPremiumUsers = [
      {
        id: '1',
        name: 'Анна Петрова',
        subscription: { type: 'monthly', price: 999, startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString() }
      }
    ];
    localStorage.setItem('elyse.premiumUsers', JSON.stringify(demoPremiumUsers));
  }

  // Инициализируем контент
  if (!localStorage.getItem('elyse.dailyTips')) {
    const demoDailyTips = [
      {
        id: '1',
        title: 'Совет дня: Любовь',
        content: 'Сегодня благоприятное время для романтических отношений. Венера в гармонии с Луной создает особую атмосферу для признаний в любви.',
        category: 'love',
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        title: 'Совет дня: Карьера',
        content: 'Меркурий в соединении с Солнцем - отличное время для важных переговоров и подписания контрактов.',
        category: 'career',
        isActive: true,
        createdAt: new Date().toISOString()
      }
    ];
    localStorage.setItem('elyse.dailyTips', JSON.stringify(demoDailyTips));
  }

  // Инициализируем AI настройки
  if (!localStorage.getItem('elyse.aiSettings')) {
    const demoAISettings = {
      model: 'gpt-4o-mini',
      temperature: 0.7,
      maxTokens: 1000,
      isEnabled: true,
      apiKey: 'demo-key-123'
    };
    localStorage.setItem('elyse.aiSettings', JSON.stringify(demoAISettings));
  }

  // Инициализируем пакеты контента
  if (!localStorage.getItem('elyse.contentPacks')) {
    const demoContentPacks = [
      {
        id: '1',
        name: 'Ежедневные гороскопы',
        description: 'Гороскопы на каждый день для всех знаков зодиака',
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        name: 'Совместимость знаков',
        description: 'Анализ совместимости между различными знаками зодиака',
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: '3',
        name: 'Лунные фазы',
        description: 'Информация о влиянии лунных фаз на повседневную жизнь',
        isActive: false,
        createdAt: new Date().toISOString()
      }
    ];
    localStorage.setItem('elyse.contentPacks', JSON.stringify(demoContentPacks));
  }

  // Инициализируем системные промпты
  if (!localStorage.getItem('elyse.systemPrompts')) {
    const demoSystemPrompts = [
      {
        id: '1',
        name: 'Основной астролог',
        prompt: 'Ты - опытный астролог с 20-летним стажем. Отвечай на вопросы пользователей, основываясь на астрологических принципах.',
        isActive: true,
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        name: 'Консультант по совместимости',
        prompt: 'Ты - специалист по астрологической совместимости. Помогай людям понять их отношения с партнерами.',
        isActive: true,
        createdAt: new Date().toISOString()
      }
    ];
    localStorage.setItem('elyse.systemPrompts', JSON.stringify(demoSystemPrompts));
  }

  // Инициализируем настройки приложения
  if (!localStorage.getItem('elyse.appSettings')) {
    const demoAppSettings = {
      name: 'Elyse Astro',
      description: 'Ваш персональный астролог',
      version: '1.0.0',
      maintenanceMode: false
    };
    localStorage.setItem('elyse.appSettings', JSON.stringify(demoAppSettings));
  }

  // Инициализируем настройки уведомлений
  if (!localStorage.getItem('elyse.notificationSettings')) {
    const demoNotificationSettings = {
      email: false,
      push: true,
      telegram: false,
      dailyHoroscope: true,
      weeklyForecast: true
    };
    localStorage.setItem('elyse.notificationSettings', JSON.stringify(demoNotificationSettings));
  }

  // Инициализируем настройки безопасности
  if (!localStorage.getItem('elyse.securitySettings')) {
    const demoSecuritySettings = {
      requireEmailVerification: false,
      twoFactorAuth: false,
      sessionTimeout: 24,
      maxLoginAttempts: 5
    };
    localStorage.setItem('elyse.securitySettings', JSON.stringify(demoSecuritySettings));
  }
};











