import { groqAI } from '../ai/groq-client';

export interface DailyTip {
  id: string;
  type: 'DAILY_TIP' | 'DO_DONT' | 'TODAYS_LUCK';
  title: string;
  content: string;
  category: string;
  backgroundImage?: string;
  backgroundColor?: string;
  textColor?: string;
}

export interface ZodiacHoroscope {
  sign: string;
  date: string;
  general: string;
  love: string;
  career: string;
  health: string;
  mood: 'positive' | 'neutral' | 'warning';
  luckyNumbers: number[];
  luckyColors: string[];
}

export interface LunarContent {
  phase: string;
  sign: string;
  percentage: number;
  advice: string;
  doList: string[];
  dontList: string[];
  energy: 'high' | 'medium' | 'low';
}

export class DailyContentGenerator {
  private zodiacSigns = [
    'Овен', 'Телец', 'Близнецы', 'Рак', 
    'Лев', 'Дева', 'Весы', 'Скорпион',
    'Стрелец', 'Козерог', 'Водолей', 'Рыбы'
  ];

  private tipCategories = [
    'Любовь', 'Карьера', 'Здоровье', 'Деньги', 
    'Духовность', 'Отношения', 'Творчество', 'Баланс'
  ];

  async generateDailyTips(count: number = 3): Promise<DailyTip[]> {
    const tips: DailyTip[] = [];
    const categories = this.getRandomCategories(count);
    
    for (let i = 0; i < count; i++) {
      const category = categories[i];
      const tipType = this.getRandomTipType();
      
      try {
        let content = '';
        let title = '';
        
        switch (tipType) {
          case 'DAILY_TIP':
            content = await groqAI.generateDailyTip(category);
            title = `Совет дня: ${category}`;
            break;
            
          case 'DO_DONT':
            content = await this.generateDosDonts(category);
            title = `Делай / Не делай: ${category}`;
            break;
            
          case 'TODAYS_LUCK':
            content = await this.generateLuckAdvice(category);
            title = `Удача сегодня: ${category}`;
            break;
        }

        tips.push({
          id: `tip_${Date.now()}_${i}`,
          type: tipType,
          title,
          content,
          category,
          backgroundColor: this.getRandomColor(),
          textColor: '#ffffff',
          backgroundImage: this.getRandomImage(category)
        });
        
      } catch (error) {
        console.error(`Failed to generate tip for ${category}:`, error);
        // Fallback content
        tips.push(this.getFallbackTip(tipType, category, i));
      }
    }
    
    return tips;
  }

  async generateZodiacHoroscopes(date: string): Promise<ZodiacHoroscope[]> {
    const horoscopes: ZodiacHoroscope[] = [];
    
    // Генерируем по 3 знака параллельно для экономии времени
    const batches = this.chunkArray(this.zodiacSigns, 3);
    
    for (const batch of batches) {
      const batchPromises = batch.map(async (sign) => {
        try {
          const horoscope = await groqAI.generateHoroscope(sign, date);
          
          return {
            sign,
            date,
            ...horoscope,
            mood: this.determineMood(horoscope.general),
            luckyNumbers: this.generateLuckyNumbers(),
            luckyColors: this.generateLuckyColors()
          };
        } catch (error) {
          console.error(`Failed to generate horoscope for ${sign}:`, error);
          return this.getFallbackHoroscope(sign, date);
        }
      });
      
      const batchResults = await Promise.all(batchPromises);
      horoscopes.push(...batchResults);
    }
    
    return horoscopes;
  }

  async generateLunarContent(date: string): Promise<LunarContent> {
    // Здесь можно интегрировать реальные астрологические вычисления
    // Пока используем упрощенную логику
    const lunarPhases = ['Новолуние', 'Растущая луна', 'Полнолуние', 'Убывающая луна'];
    const currentPhase = lunarPhases[Math.floor(Math.random() * lunarPhases.length)];
    const currentSign = this.zodiacSigns[Math.floor(Math.random() * this.zodiacSigns.length)];
    
    try {
      const advice = await groqAI.generateLunarAdvice(currentPhase, currentSign);
      const dosDonts = await this.generateLunarDosDonts(currentPhase);
      
      return {
        phase: currentPhase,
        sign: currentSign,
        percentage: Math.floor(Math.random() * 100),
        advice,
        doList: dosDonts.dos,
        dontList: dosDonts.donts,
        energy: this.determineLunarEnergy(currentPhase)
      };
    } catch (error) {
      console.error('Failed to generate lunar content:', error);
      return this.getFallbackLunarContent();
    }
  }

  // Вспомогательные методы
  private async generateDosDonts(category: string): Promise<string> {
    const systemPrompt = `Создай короткий совет в формате "Делай: ... Не делай: ..." 
    для категории ${category}. Максимум 100 символов.`;
    
    return groqAI.generateText(
      `Создай совет "делай/не делай" для темы: ${category}`,
      { systemPrompt, maxTokens: 80 }
    );
  }

  private async generateLuckAdvice(category: string): Promise<string> {
    const systemPrompt = `Создай короткий совет об удаче и возможностях дня 
    для категории ${category}. Включи конкретные действия. Максимум 120 символов.`;
    
    return groqAI.generateText(
      `Создай совет об удаче дня для темы: ${category}`,
      { systemPrompt, maxTokens: 100 }
    );
  }

  private async generateLunarDosDonts(phase: string): Promise<{ dos: string[], donts: string[] }> {
    const prompt = `Для лунной фазы "${phase}" дай 3 коротких совета что ДЕЛАТЬ и 3 что НЕ ДЕЛАТЬ`;
    
    const content = await groqAI.generateText(prompt, {
      systemPrompt: 'Ты эксперт по лунной астрологии. Давай практические советы.',
      maxTokens: 300
    });
    
    // Парсим результат (упрощенно)
    const dos = ['Медитировать', 'Планировать', 'Отдыхать'];
    const donts = ['Спорить', 'Тратить', 'Переедать'];
    
    return { dos, donts };
  }

  private getRandomCategories(count: number): string[] {
    const shuffled = [...this.tipCategories].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  }

  private getRandomTipType(): 'DAILY_TIP' | 'DO_DONT' | 'TODAYS_LUCK' {
    const types = ['DAILY_TIP', 'DO_DONT', 'TODAYS_LUCK'] as const;
    return types[Math.floor(Math.random() * types.length)];
  }

  private getRandomColor(): string {
    const colors = ['#1a1a2e', '#16213e', '#0f3460', '#533483', '#7209b7'];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  private getRandomImage(category: string): string {
    const images = {
      'Любовь': 'https://images.unsplash.com/photo-1519120944692-1a8d8cfc1056?q=80&w=1200',
      'Карьера': 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?q=80&w=1200',
      'default': 'https://images.unsplash.com/photo-1520248730239-095647cc37f1?q=80&w=1200'
    };
    
    return images[category] || images.default;
  }

  private determineMood(text: string): 'positive' | 'neutral' | 'warning' {
    const positiveWords = ['удача', 'успех', 'возможности', 'хорошо', 'благоприятно'];
    const warningWords = ['осторожно', 'избегайте', 'трудности', 'проблемы'];
    
    const lowerText = text.toLowerCase();
    
    if (warningWords.some(word => lowerText.includes(word))) return 'warning';
    if (positiveWords.some(word => lowerText.includes(word))) return 'positive';
    return 'neutral';
  }

  private generateLuckyNumbers(): number[] {
    return Array.from({ length: 3 }, () => Math.floor(Math.random() * 50) + 1);
  }

  private generateLuckyColors(): string[] {
    const colors = ['красный', 'синий', 'зеленый', 'желтый', 'фиолетовый', 'оранжевый'];
    return colors.sort(() => 0.5 - Math.random()).slice(0, 2);
  }

  private determineLunarEnergy(phase: string): 'high' | 'medium' | 'low' {
    const energyMap = {
      'Новолуние': 'low',
      'Растущая луна': 'high',
      'Полнолуние': 'high',
      'Убывающая луна': 'medium'
    };
    
    return energyMap[phase] || 'medium';
  }

  private chunkArray<T>(array: T[], size: number): T[][] {
    const chunks = [];
    for (let i = 0; i < array.length; i += size) {
      chunks.push(array.slice(i, i + size));
    }
    return chunks;
  }

  // Fallback методы для случаев сбоя AI
  private getFallbackTip(type: string, category: string, index: number): DailyTip {
    return {
      id: `fallback_tip_${index}`,
      type: type as any,
      title: `${category}: совет дня`,
      content: 'Сегодня - хороший день для новых начинаний. Доверьтесь интуиции.',
      category,
      backgroundColor: '#1a1a2e',
      textColor: '#ffffff'
    };
  }

  private getFallbackHoroscope(sign: string, date: string): ZodiacHoroscope {
    return {
      sign,
      date,
      general: 'Сегодня благоприятный день для саморазвития.',
      love: 'В отношениях возможны приятные сюрпризы.',
      career: 'Хорошее время для карьерных решений.',
      health: 'Обратите внимание на режим дня.',
      mood: 'positive',
      luckyNumbers: [7, 14, 21],
      luckyColors: ['синий', 'зеленый']
    };
  }

  private getFallbackLunarContent(): LunarContent {
    return {
      phase: 'Растущая луна',
      sign: 'Телец',
      percentage: 50,
      advice: 'Время для планирования и новых начинаний.',
      doList: ['Медитировать', 'Планировать', 'Творить'],
      dontList: ['Спорить', 'Спешить', 'Критиковать'],
      energy: 'medium'
    };
  }
}

// Экспортируем singleton
export const dailyContentGenerator = new DailyContentGenerator();

