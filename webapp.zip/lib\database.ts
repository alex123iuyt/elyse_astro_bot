import sqlite3 from 'sqlite3';
import { open, Database } from 'sqlite';

export interface BroadcastLog {
  level: 'INFO' | 'WARNING' | 'ERROR' | 'CRITICAL';
  message: string;
  metadata?: Record<string, any>;
}
import path from 'path';
import bcrypt from 'bcryptjs';

let db: Database<sqlite3.Database, sqlite3.Statement> | null = null;

export async function getDatabase() {
  if (db) return db;

  const dbPath = path.join(process.cwd(), 'broadcast.db');
  
  db = await open({
    filename: dbPath,
    driver: sqlite3.Database
  });

  // Enable foreign keys
  await db.exec('PRAGMA foreign_keys = ON');

  // Initialize tables
  await initializeTables();

  return db;
}

async function initializeTables() {
  if (!db) return;

  // Users table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      telegram_id TEXT UNIQUE,
      email TEXT UNIQUE,
      password_hash TEXT,
      name TEXT NOT NULL,
      birth_date DATE NOT NULL,
      birth_time TIME,
      birth_city TEXT NOT NULL,
      birth_country TEXT DEFAULT 'RU',
      timezone TEXT DEFAULT 'Europe/Moscow',
      zodiac_sign TEXT,
      sun_sign TEXT,
      moon_sign TEXT,
      ascendant_sign TEXT,
      role TEXT DEFAULT 'user' CHECK(role IN ('user', 'manager', 'admin')),
      is_premium BOOLEAN DEFAULT 0,
      premium_until DATETIME,
      subscription_type TEXT DEFAULT 'free',
      chat_count INTEGER DEFAULT 0,
      last_active DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Chat sessions table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS chat_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      session_token TEXT UNIQUE NOT NULL,
      is_active BOOLEAN DEFAULT 1,
      last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
  `);

  // Messages table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      content TEXT NOT NULL,
      is_from_user BOOLEAN NOT NULL,
      is_ai_generated BOOLEAN DEFAULT 0,
      admin_reply_id INTEGER,
      message_type TEXT DEFAULT 'text' CHECK(message_type IN ('text', 'system', 'admin_reply')),
      status TEXT DEFAULT 'sent' CHECK(status IN ('sent', 'delivered', 'read', 'pending')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (session_id) REFERENCES chat_sessions (id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
      FOREIGN KEY (admin_reply_id) REFERENCES users (id)
    )
  `);

  // Admin notifications table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS admin_notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      session_id INTEGER NOT NULL,
      message_id INTEGER NOT NULL,
      is_read BOOLEAN DEFAULT 0,
      admin_id INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      read_at DATETIME,
      FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
      FOREIGN KEY (session_id) REFERENCES chat_sessions (id) ON DELETE CASCADE,
      FOREIGN KEY (message_id) REFERENCES messages (id) ON DELETE CASCADE,
      FOREIGN KEY (admin_id) REFERENCES users (id)
    )
  `);

  // AI Settings table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS ai_settings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      setting_key TEXT UNIQUE NOT NULL,
      setting_value TEXT NOT NULL,
      description TEXT,
      updated_by INTEGER,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (updated_by) REFERENCES users (id)
    )
  `);

  // Content packs table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS content_packs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT,
      is_active BOOLEAN DEFAULT 1,
      pack_data TEXT, -- JSON data
      created_by INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (created_by) REFERENCES users (id)
    )
  `);

  // User subscriptions table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS user_subscriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      subscription_type TEXT NOT NULL,
      status TEXT DEFAULT 'active' CHECK(status IN ('active', 'cancelled', 'expired', 'paused')),
      starts_at DATETIME NOT NULL,
      expires_at DATETIME NOT NULL,
      auto_renew BOOLEAN DEFAULT 1,
      payment_method TEXT,
      amount DECIMAL(10,2),
      currency TEXT DEFAULT 'RUB',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
    )
  `);

  // Broadcast jobs
  await db.exec(`
    CREATE TABLE IF NOT EXISTS broadcast_jobs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      text TEXT NOT NULL,
      filter TEXT,
      total INTEGER DEFAULT 0,
      sent INTEGER DEFAULT 0,
      failed INTEGER DEFAULT 0,
      status TEXT DEFAULT 'queued' CHECK(status IN ('queued','running','done','failed','cancelled','paused')),
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      started_at DATETIME,
      finished_at DATETIME,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      image_url TEXT,
      custom_buttons TEXT,
      has_image BOOLEAN DEFAULT 0,
      has_buttons BOOLEAN DEFAULT 0
    )
  `);

  // Add new columns to existing table if they don't exist
  try { await db.run(`ALTER TABLE broadcast_jobs ADD COLUMN image_url TEXT`); } catch {}
  try { await db.run(`ALTER TABLE broadcast_jobs ADD COLUMN custom_buttons TEXT`); } catch {}
  try { await db.run(`ALTER TABLE broadcast_jobs ADD COLUMN has_image BOOLEAN DEFAULT 0`); } catch {}
  try { await db.run(`ALTER TABLE broadcast_jobs ADD COLUMN has_buttons BOOLEAN DEFAULT 0`); } catch {}

  // Create broadcast_recipients table if it doesn't exist
  await db.exec(`
    CREATE TABLE IF NOT EXISTS broadcast_recipients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      job_id INTEGER NOT NULL,
      telegram_id TEXT NOT NULL,
      user_name TEXT,
      status TEXT DEFAULT 'pending' CHECK(status IN ('pending','sent','failed','skipped')),
      error TEXT,
      sent_at DATETIME,
      FOREIGN KEY (job_id) REFERENCES broadcast_jobs (id) ON DELETE CASCADE
    )
  `);

  // Broadcast logs table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS broadcast_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      level TEXT NOT NULL CHECK(level IN ('INFO','WARNING','ERROR','CRITICAL')),
      message TEXT NOT NULL,
      metadata TEXT, -- JSON string
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // AI Generated content table
  await db.exec(`
    CREATE TABLE IF NOT EXISTS generated_content (
      id TEXT PRIMARY KEY,
      type TEXT NOT NULL,
      date TEXT NOT NULL,
      content TEXT NOT NULL,
      metadata TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Indexes for fast content retrieval
  await db.exec(`CREATE INDEX IF NOT EXISTS idx_generated_content_date ON generated_content(date)`);
  await db.exec(`CREATE INDEX IF NOT EXISTS idx_generated_content_type_date ON generated_content(type, date)`);

  // Insert default AI settings
  await db.run(`
    INSERT OR IGNORE INTO ai_settings (setting_key, setting_value, description) VALUES 
    ('system_prompt', 'Ты — астрологический помощник. Пиши кратко, дружелюбно и по-деловому. Избегай пугающих формулировок и эзотерических страшилок. Давай 1–2 чётких вывода и 1 практический совет «что сделать». Тон: поддерживающий, современный, без канцелярита.', 'Системный промпт для генерации контента'),
    ('chat_prompt', 'Ты — Моника, опытный астролог с 15-летним стажем. Отвечай как мудрая женщина-астролог, которая видит судьбу в звездах. Будь дружелюбной, но профессиональной. Всегда давай конкретные советы и объясняй, почему так происходит с точки зрения астрологии.', 'Промпт для чата с пользователями'),
    ('openai_api_key', '', 'API ключ для OpenAI'),
    ('openai_model', 'gpt-4o-mini', 'Модель OpenAI для использования'),
    ('max_tokens', '500', 'Максимальное количество токенов в ответе'),
    ('temperature', '0.7', 'Температура для генерации (0.0-2.0)')
  `);

  // Ensure at least one admin user exists
  const adminExists = await db.get(`SELECT id FROM users WHERE role = 'admin' LIMIT 1`);
  if (!adminExists) {
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@elyse.local';
    const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';
    const passwordHash = await bcrypt.hash(adminPassword, 12);

    await db.run(`
      INSERT INTO users (
        email, password_hash, name, birth_date, birth_city, role, is_premium, zodiac_sign
      ) VALUES (?, ?, ?, ?, ?, 'admin', 1, 'Стрелец')
    `, [
      adminEmail,
      passwordHash,
      'Admin',
      '1990-01-01',
      'Москва'
    ]);
  }

  console.log('Database tables initialized successfully');
}

// Helper functions for database operations
export async function createUser(userData: {
  telegram_id?: string;
  email?: string;
  password_hash?: string;
  name: string;
  birth_date: string;
  birth_time?: string;
  birth_city: string;
  birth_country?: string;
  timezone?: string;
}) {
  const db = await getDatabase();
  
  const result = await db.run(`
    INSERT INTO users (
      telegram_id, email, password_hash, name, birth_date, birth_time, 
      birth_city, birth_country, timezone, zodiac_sign
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    userData.telegram_id || null,
    userData.email || null,
    userData.password_hash || null,
    userData.name,
    userData.birth_date,
    userData.birth_time || null,
    userData.birth_city,
    userData.birth_country || 'RU',
    userData.timezone || 'Europe/Moscow',
    calculateZodiacSign(userData.birth_date)
  ]);

  return result.lastID;
}

export async function getUserById(id: number) {
  const db = await getDatabase();
  return await db.get('SELECT * FROM users WHERE id = ?', [id]);
}

export async function getUserByEmail(email: string) {
  const db = await getDatabase();
  return await db.get('SELECT * FROM users WHERE email = ?', [email]);
}

export async function getUserByTelegramId(telegram_id: string) {
  const db = await getDatabase();
  return await db.get('SELECT * FROM users WHERE telegram_id = ?', [telegram_id]);
}

export async function createChatSession(userId: number, sessionToken: string) {
  const db = await getDatabase();
  
  const result = await db.run(`
    INSERT INTO chat_sessions (user_id, session_token) VALUES (?, ?)
  `, [userId, sessionToken]);

  return result.lastID;
}

export async function createMessage(sessionId: number, userId: number, content: string, isFromUser: boolean, isAiGenerated: boolean = false) {
  const db = await getDatabase();
  
  const result = await db.run(`
    INSERT INTO messages (session_id, user_id, content, is_from_user, is_ai_generated) 
    VALUES (?, ?, ?, ?, ?)
  `, [sessionId, userId, content, isFromUser ? 1 : 0, isAiGenerated ? 1 : 0]);

  // Create admin notification for user messages
  if (isFromUser) {
    await db.run(`
      INSERT INTO admin_notifications (user_id, session_id, message_id) 
      VALUES (?, ?, ?)
    `, [userId, sessionId, result.lastID]);
  }

  return result.lastID;
}

export async function getUnreadNotifications() {
  const db = await getDatabase();
  
  return await db.all(`
    SELECT 
      an.*,
      u.name as user_name,
      u.email as user_email,
      m.content as message_content,
      m.created_at as message_time
    FROM admin_notifications an
    JOIN users u ON an.user_id = u.id
    JOIN messages m ON an.message_id = m.id
    WHERE an.is_read = 0
    ORDER BY an.created_at DESC
  `);
}

export async function getUserChatHistory(userId: number) {
  const db = await getDatabase();
  
  return await db.all(`
    SELECT 
      m.*,
      cs.session_token
    FROM messages m
    JOIN chat_sessions cs ON m.session_id = cs.id
    WHERE m.user_id = ?
    ORDER BY m.created_at ASC
  `, [userId]);
}

export async function getAllUsers(page: number = 1, limit: number = 50) {
  const db = await getDatabase();
  const offset = (page - 1) * limit;
  
  const users = await db.all(`
    SELECT 
      id, name, email, telegram_id, zodiac_sign, role, is_premium, 
      subscription_type, last_active, created_at,
      (SELECT COUNT(*) FROM messages WHERE user_id = users.id AND is_from_user = 1) as message_count
    FROM users
    ORDER BY last_active DESC
    LIMIT ? OFFSET ?
  `, [limit, offset]);

  const total = await db.get('SELECT COUNT(*) as count FROM users');
  
  return {
    users,
    total: total.count,
    page,
    limit,
    totalPages: Math.ceil(total.count / limit)
  };
}

function calculateZodiacSign(birthDate: string): string {
  const date = new Date(birthDate);
  const month = date.getMonth() + 1;
  const day = date.getDate();

  if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return 'Овен';
  if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return 'Телец';
  if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return 'Близнецы';
  if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return 'Рак';
  if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return 'Лев';
  if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return 'Дева';
  if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return 'Весы';
  if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return 'Скорпион';
  if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return 'Стрелец';
  if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return 'Козерог';
  if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return 'Водолей';
  if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return 'Рыбы';
  
  return 'Неизвестно';
}

export async function logBroadcast(logData: BroadcastLog): Promise<void> {
  try {
    const database = await getDatabase();
    await database.run(
      `INSERT INTO broadcast_logs (level, message, metadata, created_at) VALUES (?, ?, ?, ?)`,
      [
        logData.level,
        logData.message,
        logData.metadata ? JSON.stringify(logData.metadata) : null,
        new Date().toISOString()
      ]
    );
  } catch (error) {
    console.error('Failed to log broadcast:', error);
  }
}

