export default function ReadingsPage() {
  return (
    <div className="min-h-screen bg-black text-white p-6 space-y-4">
      <h1 className="text-xl font-semibold">Readings</h1>
      <div className="card">Персональные расклады/показатели — заглушка.</div>
    </div>
  )
}

















