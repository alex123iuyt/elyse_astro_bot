import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { createUser, getUserByEmail, getUserById } from './database';

const JWT_SECRET = process.env.JWT_SECRET || 'elyse-astro-secret-key-2024';
const JWT_EXPIRES_IN = '7d';

export interface UserData {
  id: number;
  name: string;
  email: string;
  role: 'user' | 'manager' | 'admin';
  zodiac_sign: string;
  is_premium: boolean;
}

export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 12;
  return await bcrypt.hash(password, saltRounds);
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return await bcrypt.compare(password, hashedPassword);
}

export function generateToken(userData: UserData): string {
  return jwt.sign(
    {
      id: userData.id,
      email: userData.email,
      role: userData.role
    },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

export function verifyToken(token: string): any {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
}

export async function registerUser(userData: {
  name: string;
  email: string;
  password: string;
  birth_date: string;
  birth_time?: string;
  birth_city: string;
  birth_country?: string;
  timezone?: string;
}) {
  // Check if user already exists
  const existingUser = await getUserByEmail(userData.email);
  if (existingUser) {
    throw new Error('Пользователь с таким email уже существует');
  }

  // Hash password
  const passwordHash = await hashPassword(userData.password);

  // Create user
  const userId = await createUser({
    email: userData.email,
    password_hash: passwordHash,
    name: userData.name,
    birth_date: userData.birth_date,
    birth_time: userData.birth_time,
    birth_city: userData.birth_city,
    birth_country: userData.birth_country,
    timezone: userData.timezone
  });

  // Get created user
  const user = await getUserById(userId as number);
  if (!user) {
    throw new Error('Ошибка создания пользователя');
  }

  // Generate token
  const token = generateToken({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    zodiac_sign: user.zodiac_sign,
    is_premium: user.is_premium
  });

  return {
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      zodiac_sign: user.zodiac_sign,
      is_premium: user.is_premium,
      birth_date: user.birth_date,
      birth_time: user.birth_time,
      birth_city: user.birth_city
    },
    token
  };
}

export async function loginUser(email: string, password: string) {
  // Get user by email
  const user = await getUserByEmail(email);
  if (!user) {
    throw new Error('Неверный email или пароль');
  }

  // Verify password
  const isPasswordValid = await verifyPassword(password, user.password_hash);
  if (!isPasswordValid) {
    throw new Error('Неверный email или пароль');
  }

  // Generate token
  const token = generateToken({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    zodiac_sign: user.zodiac_sign,
    is_premium: user.is_premium
  });

  return {
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      zodiac_sign: user.zodiac_sign,
      is_premium: user.is_premium,
      birth_date: user.birth_date,
      birth_time: user.birth_time,
      birth_city: user.birth_city
    },
    token
  };
}

export async function getUserFromToken(token: string) {
  const decoded = verifyToken(token);
  if (!decoded) {
    return null;
  }

  const user = await getUserById(decoded.id);
  if (!user) {
    return null;
  }

  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    zodiac_sign: user.zodiac_sign,
    is_premium: user.is_premium,
    birth_date: user.birth_date,
    birth_time: user.birth_time,
    birth_city: user.birth_city
  };
}

// Calculate natal chart based on birth data
export function calculateNatalChart(birthDate: string, birthTime?: string, birthCity?: string) {
  // This is a simplified version - in real app you'd use a proper astrology library
  const date = new Date(birthDate);
  const month = date.getMonth() + 1;
  const day = date.getDate();

  // Calculate Sun sign (zodiac)
  const sunSign = calculateZodiacSign(month, day);
  
  // Mock calculations for Moon and Ascendant (in real app, you'd use birth time and location)
  const moonSigns = ['Овен', 'Телец', 'Близнецы', 'Рак', 'Лев', 'Дева', 'Весы', 'Скорпион', 'Стрелец', 'Козерог', 'Водолей', 'Рыбы'];
  const moonSign = moonSigns[Math.floor(Math.random() * moonSigns.length)];
  const ascendantSign = moonSigns[Math.floor(Math.random() * moonSigns.length)];

  return {
    sun: {
      sign: sunSign,
      degree: Math.floor(Math.random() * 30) + 1,
      house: Math.floor(Math.random() * 12) + 1
    },
    moon: {
      sign: moonSign,
      degree: Math.floor(Math.random() * 30) + 1,
      house: Math.floor(Math.random() * 12) + 1
    },
    ascendant: {
      sign: ascendantSign,
      degree: Math.floor(Math.random() * 30) + 1
    }
  };
}

function calculateZodiacSign(month: number, day: number): string {
  if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return 'Овен';
  if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return 'Телец';
  if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return 'Близнецы';
  if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return 'Рак';
  if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return 'Лев';
  if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return 'Дева';
  if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return 'Весы';
  if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return 'Скорпион';
  if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return 'Стрелец';
  if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return 'Козерог';
  if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return 'Водолей';
  if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) return 'Рыбы';
  
  return 'Неизвестно';
}











