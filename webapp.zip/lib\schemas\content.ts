import { z } from 'zod'

// Базовые схемы для всех типов контента
export const baseContentSchema = z.object({
  title: z.string().min(1, 'Заголовок обязателен'),
  status: z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED']).default('DRAFT'),
  version: z.number().int().positive().default(1),
  targeting: z.object({
    sign: z.string().optional(),
    gender: z.enum(['male', 'female', 'any']).optional(),
    locale: z.string().optional(),
  }).optional(),
  schedule: z.object({
    startDate: z.string().datetime().optional(),
    endDate: z.string().datetime().optional(),
    timezone: z.string().default('Europe/Amsterdam'),
    rrule: z.string().optional(), // RRULE для повторяющихся событий
  }).optional(),
  publishedAt: z.string().datetime().optional(),
})

// Схема для DAILY_TIP_DOMAIN (совет дня по домену)
export const dailyTipDomainSchema = baseContentSchema.extend({
  type: z.literal('DAILY_TIP_DOMAIN'),
  payload: z.object({
    domain: z.enum(['love', 'balance', 'luck']),
    title: z.string().min(1, 'Заголовок совета обязателен'),
    subtitle: z.string().optional(),
    icon: z.string().optional(), // URL иконки или эмодзи
    text: z.string().min(1, 'Текст совета обязателен'),
  }),
})

// Схема для DAILY_FORECAST_DOMAIN (прогноз на сегодня по домену)
export const dailyForecastDomainSchema = baseContentSchema.extend({
  type: z.literal('DAILY_FORECAST_DOMAIN'),
  payload: z.object({
    domain: z.enum(['general', 'love', 'career', 'money', 'health']),
    text: z.string().min(1, 'Текст прогноза обязателен'),
    mood: z.enum(['positive', 'neutral', 'challenging']).optional(),
    priority: z.enum(['low', 'medium', 'high']).optional(),
  }),
})

// Схема для LUNAR_TODAY (луна на сегодня)
export const lunarTodaySchema = baseContentSchema.extend({
  type: z.literal('LUNAR_TODAY'),
  payload: z.object({
    phaseName: z.string().min(1, 'Название фазы обязательно'),
    phasePct: z.number().min(0).max(100, 'Процент фазы должен быть от 0 до 100'),
    bestTime: z.object({
      from: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Формат времени: HH:MM'),
      to: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Формат времени: HH:MM'),
    }),
    avoidTime: z.object({
      from: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Формат времени: HH:MM'),
      to: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/, 'Формат времени: HH:MM'),
    }),
    monthDay: z.number().int().min(1).max(31, 'День месяца должен быть от 1 до 31'),
    advice: z.string().min(1, 'Совет обязателен'),
    moonSign: z.string().optional(), // Знак зодиака Луны
  }),
})

// Схема для STORYLINE (сторис)
export const storylineSchema = baseContentSchema.extend({
  type: z.literal('STORYLINE'),
  payload: z.object({
    placement: z.enum(['today', 'home', 'promo']),
    slides: z.array(z.object({
      kind: z.enum(['text', 'image', 'video']),
      text: z.string().optional(),
      mediaId: z.string().optional(),
      durationMs: z.number().int().positive().default(5000),
      backgroundColor: z.string().optional(),
      textColor: z.string().optional(),
    })).min(1, 'Должен быть хотя бы один слайд'),
    activeFrom: z.string().datetime().optional(),
    activeTo: z.string().datetime().optional(),
    autoPlay: z.boolean().default(true),
    loop: z.boolean().default(false),
  }),
})

// Объединенная схема для всех типов контента
export const contentSchema = z.discriminatedUnion('type', [
  dailyTipDomainSchema,
  dailyForecastDomainSchema,
  lunarTodaySchema,
  storylineSchema,
])

// Типы для TypeScript
export type DailyTipDomain = z.infer<typeof dailyTipDomainSchema>
export type DailyForecastDomain = z.infer<typeof dailyForecastDomainSchema>
export type LunarToday = z.infer<typeof lunarTodaySchema>
export type Storyline = z.infer<typeof storylineSchema>
export type Content = z.infer<typeof contentSchema>

// Схемы для API-запросов
export const createContentSchema = z.union([
  dailyTipDomainSchema.omit({ publishedAt: true, version: true }),
  dailyForecastDomainSchema.omit({ publishedAt: true, version: true }),
  lunarTodaySchema.omit({ publishedAt: true, version: true }),
  storylineSchema.omit({ publishedAt: true, version: true }),
])

export const updateContentSchema = z.object({
  id: z.string().cuid(),
  type: z.enum(['DAILY_TIP_DOMAIN', 'DAILY_FORECAST_DOMAIN', 'LUNAR_TODAY', 'STORYLINE']).optional(),
  title: z.string().optional(),
  status: z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED']).optional(),
  payload: z.any().optional(),
  targeting: z.any().optional(),
  schedule: z.any().optional(),
})

// Схемы для фильтрации
export const contentFilterSchema = z.object({
  type: z.string().optional(),
  status: z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED']).optional(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  tz: z.string().optional(),
  domains: z.string().optional(), // для DAILY_FORECAST_DOMAIN
  placement: z.string().optional(), // для STORYLINE
})

// Схемы для генерации контента
export const generateContentSchema = z.object({
  type: z.enum(['DAILY_TIP_DOMAIN', 'DAILY_FORECAST_DOMAIN', 'LUNAR_TODAY']),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  tz: z.string().default('Europe/Amsterdam'),
  domains: z.array(z.string()).optional(), // для DAILY_FORECAST_DOMAIN
})
