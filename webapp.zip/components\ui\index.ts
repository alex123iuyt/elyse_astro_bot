export { default as Loader } from './Loader';
export { default as TBankPayment } from './TBankPayment';




