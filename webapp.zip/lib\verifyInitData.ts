export async function verifyInitData(rawInitData: string, botToken: string): Promise<boolean> {
  try {
    const { createHmac } = await import('node:crypto') as any
    const urlParams = new URLSearchParams(rawInitData)
    const hash = urlParams.get('hash') || ''
    urlParams.delete('hash')
    const data = Array.from(urlParams.entries())
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
      .map(([k, v]) => `${k}=${v}`)
      .join('\n')

    const secret = createHmac('sha256', 'WebAppData').update(botToken).digest()
    const h = createHmac('sha256', secret).update(data).digest('hex')
    return h === hash
  } catch {
    return false
  }
}


