import '../globals.css'
import { Guard } from './guard'

export default function GuardLayout({ children }: { children: React.ReactNode }) {
  return <Guard>{children}</Guard>
}



















