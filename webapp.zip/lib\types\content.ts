export enum ContentType {
  DAILY_FORECAST = 'DAILY_FORECAST',
  DAILY_FORECAST_ZODIAC = 'DAILY_FORECAST_ZODIAC',
  DAILY_FORECAST_DOMAIN = 'DAILY_FORECAST_DOMAIN',
  WEEKLY_FORECAST = 'WEEKLY_FORECAST',
  MONTHLY_FORECAST = 'MONTHLY_FORECAST',
  YEARLY_FORECAST = 'YEARLY_FORECAST',
  LUNAR_TIP = 'LUNAR_TIP',
  ASTRO_EVENT = 'ASTRO_EVENT',
  STORYLINE = 'STORYLINE',
  COMPATIBILITY = 'COMPATIBILITY',
  NATAL_TEMPLATE = 'NATAL_TEMPLATE',
  ONBOARDING_STEP = 'ONBOARDING_STEP',
  PUSH_TEMPLATE = 'PUSH_TEMPLATE',
  ARTICLE = 'ARTICLE',
  FAQ_ITEM = 'FAQ_ITEM',
  MARKETING_BANNER = 'MARKETING_BANNER',
  UI_COPY = 'UI_COPY'
}

export enum ContentStatus {
  DRAFT = 'DRAFT',
  PUBLISHED = 'PUBLISHED',
  ARCHIVED = 'ARCHIVED'
}

export interface ContentItem {
  id: string
  type: ContentType
  title: string
  slug?: string | null
  status: ContentStatus
  version: number
  payload: any
  targeting?: any
  schedule?: any
  createdAt: string
  updatedAt: string
  publishedAt?: string | null
  updatedBy: {
    name: string
    email: string
  }
}








