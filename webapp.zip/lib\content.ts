import { generate } from './ai'

type Ctx = { name?:string; zodiac?:string; date?:string }

export async function getContent(kind: 'daily'|'weekly'|'monthly'|'natal_basic'|'synastry_basic'|'lunar'|'retro', ctx: Ctx){
  // В MVP считаем, что включен AI; если появятся шаблоны — сюда вставим рендер Markdown c переменными
  return generate(kind, ctx)
}














