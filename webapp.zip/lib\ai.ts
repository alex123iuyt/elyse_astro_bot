export async function generate(
  kind: 'daily' | 'weekly' | 'monthly' | 'natal_basic' | 'synastry_basic' | 'lunar' | 'retro',
  context: { zodiac?: string; name?: string; date?: string }
): Promise<string> {
  try {
    const response = await fetch('/api/ai/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind, user_context: context })
    });
    
    if (!response.ok) {
      throw new Error('AI generation failed');
    }
    
    const data = await response.json();
    return data.text || 'Не удалось сгенерировать текст';
  } catch (error) {
    console.error('AI generation error:', error);
    return `Ошибка генерации: ${error instanceof Error ? error.message : 'неизвестная ошибка'}`;
  }
}


