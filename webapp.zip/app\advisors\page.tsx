export default function AdvisorsPage() {
  return (
    <div className="min-h-screen bg-black text-white p-6 space-y-4">
      <h1 className="text-xl font-semibold">Advisors</h1>
      <div className="card">Список астрологов появится здесь. Заглушка.</div>
    </div>
  )
}

















