import { DailyTipDomain, DailyForecastDomain, LunarToday } from './schemas/content'

// Интерфейс генератора контента
export interface ContentGenerator {
  draftDailyTips(date: string, tz: string): Promise<DailyTipDomain[]>
  draftDailyForecast(date: string, tz: string, domains: string[]): Promise<Record<string, string>>
  draftLunarToday(date: string, tz: string): Promise<LunarToday>
}

// Ручной генератор (по умолчанию) - возвращает пустые структуры
export class ManualGenerator implements ContentGenerator {
  async draftDailyTips(date: string, tz: string): Promise<DailyTipDomain[]> {
    const domains = ['love', 'balance', 'luck'] as const
    const dateObj = new Date(date)
    
    return domains.map(domain => ({
      type: 'DAILY_TIP_DOMAIN' as const,
      title: `Совет дня: ${this.getDomainLabel(domain)}`,
      status: 'DRAFT' as const,
      version: 1,
      payload: {
        domain,
        title: `Совет дня: ${this.getDomainLabel(domain)}`,
        subtitle: `На ${dateObj.toLocaleDateString('ru-RU')}`,
        icon: this.getDomainIcon(domain),
        text: `Введите совет для ${this.getDomainLabel(domain).toLowerCase()} на ${dateObj.toLocaleDateString('ru-RU')}`,
      },
      targeting: {},
      schedule: { timezone: tz },
    }))
  }

  async draftDailyForecast(date: string, tz: string, domains: string[]): Promise<Record<string, string>> {
    const dateObj = new Date(date)
    const result: Record<string, string> = {}
    
    domains.forEach(domain => {
      result[domain] = `Введите прогноз для ${this.getForecastDomainLabel(domain).toLowerCase()} на ${dateObj.toLocaleDateString('ru-RU')}`
    })
    
    return result
  }

  async draftLunarToday(date: string, tz: string): Promise<LunarToday> {
    const dateObj = new Date(date)
    
    return {
      type: 'LUNAR_TODAY' as const,
      title: `Лунный календарь на ${dateObj.toLocaleDateString('ru-RU')}`,
      status: 'DRAFT' as const,
      version: 1,
      payload: {
        phaseName: 'Растущая Луна',
        phasePct: 75,
        bestTime: { from: '09:00', to: '12:00' },
        avoidTime: { from: '15:00', to: '18:00' },
        monthDay: dateObj.getDate(),
        advice: 'Введите совет по лунному календарю на этот день',
        moonSign: 'Скорпион',
      },
      targeting: {},
      schedule: { timezone: tz },
    }
  }

  private getDomainLabel(domain: string): string {
    const labels: Record<string, string> = {
      love: 'Любовь',
      balance: 'Баланс',
      luck: 'Удача',
    }
    return labels[domain] || domain
  }

  private getForecastDomainLabel(domain: string): string {
    const labels: Record<string, string> = {
      general: 'Общий',
      love: 'Любовь',
      career: 'Карьера',
      money: 'Финансы',
      health: 'Здоровье',
    }
    return labels[domain] || domain
  }

  private getDomainIcon(domain: string): string {
    const icons: Record<string, string> = {
      love: '❤️',
      balance: '⚖️',
      luck: '🍀',
    }
    return icons[domain] || '✨'
  }
}

// OpenAI генератор (опционально)
export class OpenAIContentGenerator implements ContentGenerator {
  private apiKey: string

  constructor(apiKey: string) {
    this.apiKey = apiKey
  }

  async draftDailyTips(date: string, tz: string): Promise<DailyTipDomain[]> {
    try {
      // Здесь будет интеграция с OpenAI API
      // Пока возвращаем базовые структуры
      const manualGenerator = new ManualGenerator()
      return await manualGenerator.draftDailyTips(date, tz)
    } catch (error) {
      console.error('OpenAI generation failed, falling back to manual:', error)
      const manualGenerator = new ManualGenerator()
      return await manualGenerator.draftDailyTips(date, tz)
    }
  }

  async draftDailyForecast(date: string, tz: string, domains: string[]): Promise<Record<string, string>> {
    try {
      // Здесь будет интеграция с OpenAI API
      const manualGenerator = new ManualGenerator()
      return await manualGenerator.draftDailyForecast(date, tz, domains)
    } catch (error) {
      console.error('OpenAI generation failed, falling back to manual:', error)
      const manualGenerator = new ManualGenerator()
      return await manualGenerator.draftDailyForecast(date, tz, domains)
    }
  }

  async draftLunarToday(date: string, tz: string): Promise<LunarToday> {
    try {
      // Здесь будет интеграция с OpenAI API
      const manualGenerator = new ManualGenerator()
      return await manualGenerator.draftLunarToday(date, tz)
    } catch (error) {
      console.error('OpenAI generation failed, falling back to manual:', error)
      const manualGenerator = new ManualGenerator()
      return await manualGenerator.draftLunarToday(date, tz)
    }
  }
}

// Фабрика для создания генератора
export function createContentGenerator(): ContentGenerator {
  const generatorType = process.env.GENERATOR || 'manual'
  
  if (generatorType === 'openai') {
    const apiKey = process.env.OPENAI_API_KEY
    if (!apiKey) {
      console.warn('OPENAI_API_KEY not set, falling back to manual generator')
      return new ManualGenerator()
    }
    return new OpenAIContentGenerator(apiKey)
  }
  
  return new ManualGenerator()
}

// Экспорт по умолчанию
export const contentGenerator = createContentGenerator()
