import { promises as fs } from 'fs';
import path from 'path';

const BOT_USERS_FILE = path.join(process.cwd(), 'data', 'bot-users.json');

export interface BotUser {
  id: string;
  telegram_id: string;
  name: string;
  username?: string;
  birth_date?: string;
  birth_city?: string;
  timezone?: string;
  zodiac_sign?: string;
  is_premium: boolean;
  last_active: string;
  created_at: string;
  message_count: number;
}

export async function getBotUsers(): Promise<BotUser[]> {
  try {
    console.log('[BOT_USERS] Reading file:', BOT_USERS_FILE);
    const data = await fs.readFile(BOT_USERS_FILE, 'utf-8');
    const parsed = JSON.parse(data);
    console.log('[BOT_USERS] Parsed data, users count:', parsed.users?.length || 0);
    return parsed.users || [];
  } catch (error) {
    console.error('[BOT_USERS] Error reading file:', error);
    return [];
  }
}

export async function saveBotUsers(users: BotUser[]): Promise<void> {
  await fs.writeFile(BOT_USERS_FILE, JSON.stringify({ users }, null, 2));
}

export async function upsertBotUser(telegramId: string, userData: Partial<BotUser>): Promise<BotUser> {
  const users = await getBotUsers();
  const existingIndex = users.findIndex(u => u.telegram_id === telegramId);
  
  const now = new Date().toISOString();
  
  if (existingIndex >= 0) {
    // Обновляем существующего пользователя
    const existingUser = users[existingIndex];
    const updatedUser: BotUser = {
      ...existingUser,
      name: userData.name || existingUser.name,
      username: userData.username !== undefined ? userData.username : existingUser.username,
      birth_date: userData.birth_date || existingUser.birth_date,
      birth_city: userData.birth_city || existingUser.birth_city,
      timezone: userData.timezone || existingUser.timezone,
      zodiac_sign: userData.zodiac_sign || existingUser.zodiac_sign,
      is_premium: userData.is_premium !== undefined ? userData.is_premium : existingUser.is_premium,
      last_active: now,
      message_count: userData.message_count !== undefined ? 
        existingUser.message_count + userData.message_count : 
        existingUser.message_count
    };
    
    users[existingIndex] = updatedUser;
    await saveBotUsers(users);
    return updatedUser;
  } else {
    // Создаем нового пользователя
    const newUser: BotUser = {
      id: `tg_${telegramId}`,
      telegram_id: telegramId,
      name: userData.name || `User ${telegramId}`,
      username: userData.username,
      birth_date: userData.birth_date || '2000-01-01',
      birth_city: userData.birth_city || 'Unknown',
      timezone: userData.timezone || 'Europe/Moscow',
      zodiac_sign: userData.zodiac_sign || 'Unknown',
      is_premium: userData.is_premium || false,
      last_active: now,
      created_at: now,
      message_count: userData.message_count || 1
    };
    
    users.push(newUser);
    await saveBotUsers(users);
    return newUser;
  }
}

export async function getBotUserByTelegramId(telegramId: string): Promise<BotUser | null> {
  const users = await getBotUsers();
  return users.find(u => u.telegram_id === telegramId) || null;
}

export async function updateBotUserActivity(telegramId: string): Promise<void> {
  const users = await getBotUsers();
  const userIndex = users.findIndex(u => u.telegram_id === telegramId);
  
  if (userIndex >= 0) {
    users[userIndex].last_active = new Date().toISOString();
    await saveBotUsers(users);
  }
}

export async function getBotUsersForBroadcast(segment?: string, inactiveDays?: number, zodiac?: string): Promise<BotUser[]> {
  console.log('[BOT_USERS] getBotUsersForBroadcast called with:', { segment, inactiveDays, zodiac });
  
  const users = await getBotUsers();
  console.log('[BOT_USERS] getBotUsers returned:', users.length, 'users');
  
  // Фильтруем только валидные Telegram ID (числовые)
  const validUsers = users.filter(u => /^\d+$/.test(u.telegram_id));
  console.log('[BOT_USERS] Valid Telegram IDs:', validUsers.length, 'users');
  
  let filteredUsers: BotUser[] = [];
  
  if (segment === 'premium') {
    filteredUsers = validUsers.filter(u => u.is_premium);
    console.log('[BOT_USERS] Filtered by premium:', filteredUsers.length, 'users');
  } else if (segment === 'inactive' && inactiveDays) {
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - inactiveDays);
    filteredUsers = validUsers.filter(u => new Date(u.last_active) < cutoff);
    console.log('[BOT_USERS] Filtered by inactive days:', filteredUsers.length, 'users');
  } else if (segment === 'zodiac' && zodiac) {
    filteredUsers = validUsers.filter(u => u.zodiac_sign === zodiac);
    console.log('[BOT_USERS] Filtered by zodiac:', filteredUsers.length, 'users');
  } else {
    filteredUsers = validUsers;
    console.log('[BOT_USERS] No filtering applied, returning valid users:', filteredUsers.length);
  }
  
  console.log('[BOT_USERS] Final result:', filteredUsers.length, 'users');
  return filteredUsers;
}

